from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from .api_studio import router as studio_router
from .config_schema import ChecklistConfig
from .db import SessionLocal, init_db
from .services import save_checklist_version

app = FastAPI(title="Freedom Broker CQA")
app.include_router(studio_router)


@app.on_event("startup")
def _startup() -> None:
    init_db()
    seed = Path(__file__).parent.parent / "config" / "official_chat_v1.json"
    with SessionLocal() as s:  # idempotent: same content hash -> no new version
        save_checklist_version(s, "official-chat", ChecklistConfig.model_validate_json(seed.read_text()),
                               change_note="Official checklist seed", author="system")


app.mount("/", StaticFiles(directory=Path(__file__).parent.parent / "static", html=True), name="static")
